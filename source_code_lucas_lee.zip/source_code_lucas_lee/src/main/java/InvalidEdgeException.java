public class InvalidEdgeException extends RuntimeException {
    protected InvalidEdgeException(String message) {
        super(message);
    }
}
