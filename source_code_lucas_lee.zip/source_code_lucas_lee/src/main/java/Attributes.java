public class Attributes {
    protected static final String LABEL = "ui.label";
    protected static final String STYLESHEET = "ui.stylesheet";
    protected static final String CLASS = "ui.class";
}
