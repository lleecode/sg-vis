public class InvalidNodeException extends RuntimeException {
    protected InvalidNodeException(String message) {
        super(message);
    }
}
